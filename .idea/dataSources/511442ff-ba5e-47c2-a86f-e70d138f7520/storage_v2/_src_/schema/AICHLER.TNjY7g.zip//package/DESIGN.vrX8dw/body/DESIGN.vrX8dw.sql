create PACKAGE body design is 

procedure add_design_type(id_c integer, name_c varchar2) is
begin
insert into design_type(id_design_type, name) values(id_c, name_c);
commit;
end;

procedure del_instrum(id_c integer) is
begin
delete from design_type where design_type.id_design_type = id_c;
commit;
end;

procedure upd_instrum(id_c integer, name_c varchar2) is
begin
update design_type set design_type.name = name_c where id_design_type = id_c;
commit;
end;

procedure search_instrum(id_c integer) is
str varchar2(30);
begin
select name into str from design_type where design_type.id_design_type = id_c;
dbms_output.enable;
dbms_output.put_line(str);
end;
END ;
/

