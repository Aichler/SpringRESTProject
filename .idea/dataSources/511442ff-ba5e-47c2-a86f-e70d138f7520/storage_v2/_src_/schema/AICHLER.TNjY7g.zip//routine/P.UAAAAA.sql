create procedure P(text_ varchar2) is
  begin  
    dbms_output.put_line(text_);
  end;
/

