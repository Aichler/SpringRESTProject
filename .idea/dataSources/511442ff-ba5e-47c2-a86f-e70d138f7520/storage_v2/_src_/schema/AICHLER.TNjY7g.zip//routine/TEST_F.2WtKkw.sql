create function test_F(a IN number, b IN OUT integer, c OUT varchar2, d date := sysdate) is   
 returning varchar2 is 
 e date  := d - a;
 res varchar (4000) := to_char(e ='||12:25:09');
 begin
  c := to_char(a+b, '||999G9865D');
  b := b + a;
  return res;
  end;
/

