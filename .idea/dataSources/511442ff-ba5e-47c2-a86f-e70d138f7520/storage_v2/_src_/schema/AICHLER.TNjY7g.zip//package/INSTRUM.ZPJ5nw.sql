create package instrum is
procedure add_instrum(id_c integer, name_c varchar2);
procedure upd_instrum(id_c integer, name_c varchar2);
procedure del_instrum(id_c integer);
procedure search_instrum(id_c integer);
end;
/

