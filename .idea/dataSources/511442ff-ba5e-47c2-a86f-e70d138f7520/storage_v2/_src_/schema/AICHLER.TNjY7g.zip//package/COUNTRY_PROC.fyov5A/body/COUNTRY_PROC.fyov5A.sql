create package body country_proc is

procedure add_val_c(name_c varchar2) is
begin
insert into Country(id_country, name) values(main_seq.nextval, name_c);
commit;
end;

procedure del_val_c(id_c integer) is
begin
delete from Country where Country.id_country = id_c;
commit;
end;

procedure upd_val_c(id_c integer, name_c varchar2) is
begin
update Country set Country.name = name_c where id_country = id_c;
commit;
end;

procedure search_c is
begin
FOR w IN (select* from country ORDER BY name) LOOP
dbms_output.put_line(w.name||'   '||w.id_country);
END LOOP;
end;

end;
/

