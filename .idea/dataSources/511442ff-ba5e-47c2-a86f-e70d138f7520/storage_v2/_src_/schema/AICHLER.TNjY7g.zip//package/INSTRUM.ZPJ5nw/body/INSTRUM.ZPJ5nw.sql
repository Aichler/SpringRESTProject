create PACKAGE body INSTRUM iS 

procedure add_instrum(id_c integer, name_c varchar2) is
begin
insert into instrument(id_instrument, name) values(id_c, name_c);
commit;
end;

procedure del_instrum(id_c integer) is
begin
delete from instrument where instrument.id_instrument = id_c;
commit;
end;

procedure upd_instrum(id_c integer, name_c varchar2) is
begin
update instrument set instrument.name = name_c where id_instrument = id_c;
commit;
end;

procedure search_instrum(id_c integer) is
str varchar2(30);
begin
select name into str from instrument where instrument.id_instrument = id_c;
dbms_output.enable;
dbms_output.put_line(str);
end;
END ;
/

