create package country_proc is
procedure add_val_c(name_c varchar2);
procedure upd_val_c(id_c integer, name_c varchar2);
procedure del_val_c(id_c integer);
procedure search_c;
end;
/

