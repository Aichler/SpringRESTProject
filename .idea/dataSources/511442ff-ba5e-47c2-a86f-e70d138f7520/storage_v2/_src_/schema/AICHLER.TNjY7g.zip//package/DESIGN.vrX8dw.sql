create package design is
procedure add_design_type(id_c integer, name_c varchar2);
procedure upd_design_type(id_c integer, name_c varchar2);
procedure del_design_type(id_c integer);
procedure search_design_type(id_c integer);
end;
/

