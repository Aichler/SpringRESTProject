create package body country_package is

procedure add_values(id_c integer, name_c varchar2) is
begin
insert into Country(id_country, name) values(id_c, name_c);
commit;
end add_values;

procedure del_values(name_c varchar2) is
begin
delete from Country where Country.name = name_c;
commit;
end del_values;

procedure update_values(id_c integer, name_c varchar2) is
begin
update Country set Country.name = name_c where id_country = id_c;
commit;
end update_values;

procedure search_country(id_c integer) is
str varchar2(30);
begin
select name into str from Country where Country.id_country = id_c;
dbms_output.enable;
dbms_output.put_line(str);
end search_country;

end country_package;
/

